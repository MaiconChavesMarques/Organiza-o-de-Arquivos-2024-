/*
Obtida no https://runcodes.icmc.usp.br/
*/

#ifndef _HELP_H
#define _HELP_H

  void binarioNaTela(char *nomeArquivoBinario);
  void scan_quote_string(char *str);
  
#endif
